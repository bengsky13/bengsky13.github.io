import sys, signal
from secrets import randbelow
from math import gcd
from Crypto.Util.number import getPrime, inverse
import random
from libnum import n2s

rbits = lambda x: random.getrandbits(x)

R=12;BITS=1024;M_BITS=81*81;TIME=200;DIF=1000
signal.signal(signal.SIGALRM,lambda *_:(print("timeout"),sys.exit(1)))
signal.alarm(TIME)
M1 = randbelow(1<<M_BITS) or 1
ss = []

def one_round(i):
    p,q=getPrime(BITS),getPrime(BITS)
    N=p*q
    a,b,c=rbits(DIF),rbits(DIF),rbits(DIF*6)
    g=gcd(a, b)
    a//=g
    b//=g
    phi=(p**3-a)*(q**3-b)
    d=getPrime(BITS)
    e=inverse(d,phi)
    f=e*M1+c
    s=randbelow(N-2)
    m2=M1*a+b
    z=pow(s,e*d,N)
    U2=pow(s+m2*N,d,N*N)
    print(f"=== Round {i}/{R} ===")
    print(f"N = {n2s(N).hex()}")
    print(f"a/b = {n2s((a * pow(b, -1, N)) % N).hex()}")
    print(f"f = {n2s(f).hex()}")
    print(f"z = {n2s(z).hex()}")
    print(f"g = {n2s(g).hex()}")
    print(f"U2 = {n2s(U2).hex()}")
    ss.append(s)

for i in range(1,R+1):one_round(i)
for i in range(1,R+1):
    g = int(input(f"Enter guess for round {i}/{R} >> "))
    if g == ss[i-1]: print("Nice!")
    else:
        print("Fail!")
        exit(1)
print(open("flag.txt").read().strip())
